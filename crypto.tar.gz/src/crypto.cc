#include <gmpxx.h>
#include <iostream>

using namespace std;

int main(char** argv, int argc){
	cout << "Hello World" << endl;
}
